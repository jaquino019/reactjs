/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx,ts,tsx}"
  ],
  theme: {
    extend: {
      backgroundImage: {
        "accenture-gradient":
          "linear-gradient(135deg, rgba(255,127,80,1) 0%, rgba(123,47,247,1) 50%, rgba(26,11,140,1) 100%)",
      },
      colors: {
        accentPurple: "#7b2ff7",
        accentDark: "#1a0b8c",
        accentCoral: "#ff7f50",
      },
    },
  },
  plugins: [],
};
