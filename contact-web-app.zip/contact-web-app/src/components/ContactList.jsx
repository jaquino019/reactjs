// src/components/ContactList.jsx
import React from "react";
import ReactLogo from "../assets/react.svg"; // Make sure this exists in your assets folder

const ContactList = ({
  contacts,
  handleView,
  handleUpdate,
  handleDelete,
  handlePrevPage,
  handleNextPage,
  currentPage,
  totalPages,
  loading, // passed from HomePage
}) => {
  return (
    <div className="bg-white bg-opacity-10 backdrop-blur-lg rounded-lg p-6 shadow-lg w-full">
      <table className="w-full text-white border-collapse">
        <thead>
          <tr className="bg-purple-800 bg-opacity-50">
            <th className="border border-purple-600 px-3 py-2">CID</th>
            <th className="border border-purple-600 px-10 py-2">Full Name</th>
            <th className="border border-purple-600 px-3 py-2">Email Address</th>
            <th className="border border-purple-600 px-4 py-2">Contact No.</th>
            <th className="border border-purple-600 px-3 py-2">Location</th>
            <th className="border border-purple-600 px-3 py-2">Date Created</th>
            <th className="border border-purple-600 px-4 py-2">Actions</th>
          </tr>
        </thead>
        <tbody>
          {loading ? (
            <tr>
              <td
                colSpan="7"
                className="text-center py-10 text-gray-300 border border-purple-600"
              >
                <div className="flex flex-col items-center justify-center">
                  <img
                    src={ReactLogo}
                    alt="Loading..."
                    className="w-12 h-12 animate-spin mb-3"
                  />
                  <span className="text-lg font-semibold">Fetching data...</span>
                </div>
              </td>
            </tr>
          ) : contacts.length > 0 ? (
            contacts.map((contact) => (
              <tr
                key={contact.id}
                className="border-b border-white/30 hover:bg-white/20 text-sm leading-tight"
              >
                <td className="px-3 py-2">{contact.cid}</td>
                <td className="px-10 py-2">{contact.fullName}</td>
                <td className="px-3 py-2">{contact.email}</td>
                <td className="px-5 py-2">{contact.contactNumber}</td>
                <td className="px-3 py-2">{contact.location}</td>
                <td className="px-5 py-2">{contact.registeredDate}</td>
                <td className="px-5 py-2 flex gap-1">
                  <button
                    onClick={() => handleView(contact.id)}
                    className="bg-blue-500 hover:bg-blue-600 text-white px-2 py-1 rounded text-xs"
                  >
                    View
                  </button>
                  <button
                    onClick={() => handleUpdate(contact.id)}
                    className="bg-yellow-500 hover:bg-yellow-600 text-white px-2 py-1 rounded text-xs"
                  >
                    Update
                  </button>
                  <button
                    onClick={() => handleDelete(contact.id)}
                    className="bg-red-500 hover:bg-red-600 text-white px-2 py-1 rounded text-xs"
                  >
                    Delete
                  </button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td
                colSpan="7"
                className="text-center py-4 text-gray-300 border border-purple-600"
              >
                No contacts found.
              </td>
            </tr>
          )}
        </tbody>
      </table>

      {/* Pagination Controls */}
      <div className="flex justify-center items-center gap-4 mt-4 min-h-[48px]">
        {loading ? (
          <div className="flex flex-col items-center justify-center">
            <img
              src={ReactLogo}
              alt="Loading..."
              className="w-8 h-8 animate-spin mb-1"
            />
            <span className="text-sm">Loading...</span>
          </div>
        ) : (
          <>
            <button
              onClick={handlePrevPage}
              disabled={currentPage === 1}
              className="bg-purple-600 hover:bg-purple-700 disabled:bg-gray-500 text-white px-4 py-2 rounded-md"
            >
              Prev
            </button>

            <span className="text-white font-semibold">
              Page {currentPage} of {totalPages}
            </span>

            <button
              onClick={handleNextPage}
              disabled={currentPage === totalPages}
              className="bg-purple-600 hover:bg-purple-700 disabled:bg-gray-500 text-white px-4 py-2 rounded-md"
            >
              Next
            </button>
          </>
        )}
      </div>
    </div>
  );
};

export default ContactList;
