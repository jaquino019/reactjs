
export default function ErrorMessage({ message }) {
  if (!message) return null;
  return (
    <div className="mt-2 px-3 py-2 rounded border border-red-300 bg-red-50 text-red-700 text-sm animate-fade-in">
      {message}
    </div>
  );
}
