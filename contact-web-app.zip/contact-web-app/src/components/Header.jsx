import { Link } from "react-router-dom";
import ReactLogo from "../assets/react.svg";

export default function Header() {
  return (
    <header className="flex justify-between items-center bg-white bg-opacity-10 backdrop-blur-md text-white px-6 py-4 rounded-lg shadow-lg">
      <div className="flex items-center gap-3">
        <img
          src={ReactLogo}
          alt="React Logo"
          className="w-10 h-10 animate-spin-slow"
        />
        <h1 className="text-xl md:text-2xl font-bold">
          Contact List Web Application using ReactJS
        </h1>
      </div>
      <nav className="flex gap-4">
        <Link
          to="/"
          className="bg-white bg-opacity-20 text-white px-4 py-2 rounded-lg font-semibold hover:bg-opacity-30 transition"
        >
          Home
        </Link>
        <Link
          to="/pagination"
          className="bg-white bg-opacity-20 text-white px-4 py-2 rounded-lg font-semibold hover:bg-opacity-30 transition"
        >
          Paginated View
        </Link>
      </nav>
    </header>
  );
}
