

const Footer = () => {
  return (
    <footer className="bg-white bg-opacity-10 backdrop-blur-md shadow-md text-white p-4 text-center mt-auto">
      <p>&copy; {new Date().getFullYear()} My Contact App. All rights reserved.</p>
    </footer>
  );
};

export default Footer;
