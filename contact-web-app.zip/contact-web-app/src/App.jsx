
import { Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage.jsx';
import PaginationPage from './pages/PaginationPages.jsx';
import ViewContact from './pages/ViewContact.jsx';
import UpdateContact from './pages/UpdateContact.jsx';
import DeleteContact from './pages/DeleteContact.jsx';

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/pagination" element={<PaginationPage />} />
      <Route path="/view/:id" element={<ViewContact />} />
      <Route path="/update/:id" element={<UpdateContact />} />
      <Route path="/delete/:id" element={<DeleteContact />} />
    </Routes>
  );
}
