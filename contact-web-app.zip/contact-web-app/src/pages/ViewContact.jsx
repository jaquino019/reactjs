// src/pages/ViewContact.jsx
import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import Header from "../components/Header";
import Footer from "../components/Footer";

const ViewContact = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [contact, setContact] = useState(null);

  useEffect(() => {
    axios
      .get(`http://localhost:5001/contacts/${id}`)
      .then((res) => setContact(res.data))
      .catch((err) => console.error(err));
  }, [id]);

  if (!contact) return <div className="text-white p-4">Loading...</div>;

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-r from-purple-800 via-purple-600 to-pink-500">
      <Header />
      <main className="flex-grow flex items-center justify-center p-6">
        <div className="p-6 text-white bg-white bg-opacity-10 rounded-lg shadow-lg w-full max-w-2xl mx-auto">
          <h2 className="text-xl font-bold mb-6">View Contact</h2>

          <div className="space-y-3 text-lg">
            <p><strong>CID:</strong> {contact.cid}</p>
            <p><strong>Full Name:</strong> {contact.fullName}</p>
            <p><strong>Email Address:</strong> {contact.email}</p>
            <p><strong>Contact No:</strong> {contact.contactNumber}</p>
            <p><strong>Location:</strong> {contact.location}</p>
            <p><strong>Date Created:</strong> {contact.registeredDate}</p>
          </div>

          <div className="mt-6 flex justify-end">
            <button
              onClick={() => navigate(-1)}
              className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-md"
            >
              Back
            </button>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default ViewContact;
