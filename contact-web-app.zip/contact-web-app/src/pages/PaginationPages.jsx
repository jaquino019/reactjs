import React, { useEffect, useState } from "react";
import axios from "axios";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { useNavigate } from "react-router-dom";

const PaginationPage = () => {
  const [contacts, setContacts] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const pageSize = 5;

  useEffect(() => {
    setLoading(true);
    axios
      .get("http://localhost:5001/contacts")
      .then((res) => {
        setTotalPages(Math.ceil(res.data.length / pageSize));
        const startIndex = (currentPage - 1) * pageSize;
        const paginatedData = res.data.slice(startIndex, startIndex + pageSize);
        setContacts(paginatedData);
        setLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setLoading(false);
      });
  }, [currentPage]);

  return (
    <div className="flex flex-col min-h-screen text-white">
      {/* Header */}
      <Header />

      {/* Main content */}
      <main className="flex-1 p-4">
        <h2 className="text-xl font-semibold mb-4">Paginated Contact List</h2>
        <div className="overflow-x-auto list-card p-4">
          <table className="w-full text-sm leading-tight">
            <thead>
              <tr className="bg-white/20">
                <th className="px-10 py-5 text-left">CID</th>
                <th className="px-10 py-5 text-left">Full Name</th>
                <th className="px-10 py-5 text-left">Email</th>
                <th className="px-10 py-5 text-left">Contact No.</th>
                <th className="px-10 py-5 text-left">Location</th>
                <th className="px-10 py-5 text-left">Actions</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan="6" className="text-center py-4 text-gray-300">
                    Fetching data...
                  </td>
                </tr>
              ) : contacts.length === 0 ? (
                <tr>
                  <td colSpan="6" className="text-center py-4 text-gray-300">
                    No data available
                  </td>
                </tr>
              ) : (
                contacts.map((contact) => (
                  <tr
                    key={contact.id}
                    className="border-b border-white/20 hover:bg-white/10"
                  >
                    <td className="px-10 py-5">{contact.cid}</td>
                    <td className="px-10 py-5">{contact.fullName}</td>
                    <td className="px-10 py-5">{contact.email}</td>
                    <td className="px-10 py-5">{contact.contactNumber}</td>
                    <td className="px-10 py-5">{contact.location}</td>
                    <td className="px-2 py-1 flex gap-1">
                      <button
                        onClick={() => navigate(`/view/${contact.id}`)}
                        className="bg-blue-500 hover:bg-blue-600 text-white px-2 py-1 rounded text-xs"
                      >
                        View
                      </button>
                      <button
                        onClick={() => navigate(`/update/${contact.id}`)}
                        className="bg-yellow-500 hover:bg-yellow-600 text-white px-2 py-1 rounded text-xs"
                      >
                        Update
                      </button>
                      <button
                        onClick={() => navigate(`/delete/${contact.id}`)}
                        className="bg-red-500 hover:bg-red-600 text-white px-2 py-1 rounded text-xs"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>

          {/* Pagination controls */}
          <div className="flex justify-center items-center gap-4 mt-4">
            <button
              onClick={() => navigate("/")}
              className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded"
            >
              Back
            </button>
            <button
              onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              className="bg-purple-500 hover:bg-purple-600 text-white px-3 py-1 rounded"
            >
              Prev
            </button>
            <span>
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() =>
                setCurrentPage((prev) => Math.min(prev + 1, totalPages))
              }
              disabled={currentPage === totalPages}
              className="bg-purple-500 hover:bg-purple-600 text-white px-3 py-1 rounded"
            >
              Next
            </button>
          </div>
        </div>
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
};

export default PaginationPage;
