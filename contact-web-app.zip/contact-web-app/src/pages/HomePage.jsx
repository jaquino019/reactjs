// src/pages/HomePage.jsx
import React, { useEffect, useState } from "react";
import axios from "axios";
import ContactForm from "../components/ContactForm";
import ContactList from "../components/ContactList";
import Header from "../components/Header";
import Footer from "../components/Footer";
import { useNavigate } from "react-router-dom";

const HomePage = () => {
  const [contacts, setContacts] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true); // Added loading state
  const navigate = useNavigate();
  const itemsPerPage = 5;

  // Fetch contacts from backend
  const fetchContacts = () => {
    setLoading(true); // Start loading
    axios
      .get("http://localhost:5001/contacts")
      .then((res) => {
        const allContacts = res.data;
        setTotalPages(Math.ceil(allContacts.length / itemsPerPage));

        const startIndex = (currentPage - 1) * itemsPerPage;
        const paginatedData = allContacts.slice(
          startIndex,
          startIndex + itemsPerPage
        );
        setContacts(paginatedData);
      })
      .catch((err) => console.error(err))
      .finally(() => {
        setLoading(false); // Stop loading
      });
  };

  useEffect(() => {
    fetchContacts();
  }, [currentPage]);

  // Pagination handlers
  const handlePrevPage = () => {
    if (currentPage > 1) setCurrentPage((prev) => prev - 1);
  };
  const handleNextPage = () => {
    if (currentPage < totalPages) setCurrentPage((prev) => prev + 1);
  };

  // Button handlers
  const handleView = (id) => navigate(`/view/${id}`);
  const handleUpdate = (id) => navigate(`/update/${id}`);
  const handleDelete = (id) => navigate(`/delete/${id}`);

  return (
    <div className="flex flex-col min-h-screen text-white">
      {/* Header */}
      <Header />

      {/* Main content area */}
      <main className="flex flex-1 p-4 gap-4">
        {/* Left Column - Contact Form */}
        <div className="w-[30%] form-card p-4">
          <h2 className="text-xl font-semibold mb-4">Add New Contact</h2>
          <ContactForm onContactAdded={fetchContacts} />
        </div>

        {/* Right Column - Contact List */}
        <div className="w-[70%] list-card p-4 overflow-x-auto">
          <h2 className="text-xl font-semibold mb-4">Contact List</h2>
          <ContactList
            contacts={contacts}
            handleView={handleView}
            handleUpdate={handleUpdate}
            handleDelete={handleDelete}
            handlePrevPage={handlePrevPage}
            handleNextPage={handleNextPage}
            currentPage={currentPage}
            totalPages={totalPages}
            loading={loading} // Pass loading to ContactList
          />
        </div>
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
};

export default HomePage;
