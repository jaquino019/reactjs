// src/pages/UpdateContact.jsx
import React, { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import Header from "../components/Header";
import Footer from "../components/Footer";

const UpdateContact = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [contact, setContact] = useState(null);
  const [originalContact, setOriginalContact] = useState(null);
  const [error, setError] = useState("");
  const [showConfirm, setShowConfirm] = useState(false);
  const [changes, setChanges] = useState({});

  useEffect(() => {
    axios
      .get(`http://localhost:5001/contacts/${id}`)
      .then((res) => {
        setContact(res.data);
        setOriginalContact(res.data);
      })
      .catch((err) => console.error(err));
  }, [id]);

  const handleChange = (e) => {
    setContact({ ...contact, [e.target.name]: e.target.value });
  };

  const handleSaveClick = () => {
    // Basic empty field validation
    if (
      !contact.email.trim() ||
      !contact.contactNumber.trim() ||
      !contact.location.trim()
    ) {
      setError("All fields must be filled out.");
      return;
    }

    // Email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(contact.email)) {
      setError("Please enter a valid email address.");
      return;
    }

    // Contact number validation
    const phoneRegex = /^(09|\+639)\d{9}$/;
    if (!phoneRegex.test(contact.contactNumber)) {
      setError("Please enter a valid Philippine contact number.");
      return;
    }

    // Check if nothing changed
    if (
      contact.email === originalContact.email &&
      contact.contactNumber === originalContact.contactNumber &&
      contact.location === originalContact.location
    ) {
      setError("No changes detected.");
      return;
    }

    // Collect changes for confirmation
    const changedFields = {};
    Object.keys(contact).forEach((key) => {
      if (contact[key] !== originalContact[key]) {
        changedFields[key] = {
          old: originalContact[key],
          new: contact[key],
        };
      }
    });

    setChanges(changedFields);
    setShowConfirm(true);
    setError("");
  };

  const handleConfirmSave = () => {
    axios
      .put(`http://localhost:5001/contacts/${id}`, contact)
      .then(() => navigate("/"))
      .catch((err) => console.error(err));
  };

  if (!contact) return <div className="text-white p-4">Loading...</div>;

  // Determine location options based on current value
  const locationOptions =
    contact.location === "Manila"
      ? ["Manila", "Cebu"]
      : ["Cebu", "Manila"];

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-pink-500 via-purple-600 to-blue-500">
      <Header />

      <main className="flex-1 flex justify-center items-center px-4">
        <div className="p-6 text-white bg-white bg-opacity-10 rounded-lg shadow-lg w-full max-w-2xl">
          <h2 className="text-xl font-bold mb-4">Update Contact</h2>

          {error && (
            <div className="bg-red-500 text-white p-2 mb-4 rounded">
              {error}
            </div>
          )}

          <div className="space-y-3">
            <p>
              <strong>CID:</strong> {contact.cid}
            </p>
            <p>
              <strong>Full Name:</strong> {contact.fullName}
            </p>

            <label className="block">Email Address</label>
            <input
              type="email"
              name="email"
              value={contact.email}
              onChange={handleChange}
              placeholder="example@email.com"
              className="w-full p-2 rounded-md bg-purple-900 bg-opacity-30 text-white placeholder-gray-300"
            />

            <label className="block">Contact Number</label>
            <input
              type="text"
              name="contactNumber"
              value={contact.contactNumber}
              onChange={handleChange}
              placeholder="eg. 09123456789"
              className="w-full p-2 rounded-md bg-purple-900 bg-opacity-30 text-white placeholder-gray-300"
            />

            <label className="block">Location</label>
            <select
              name="location" 
              value={contact.location}
              onChange={handleChange}
              className="w-full p-2 rounded-md bg-purple-900 bg-opacity-30 text-white"
            >
              {locationOptions.map((loc) => (
                <option
                  key={loc}
                  value={loc}
                  className="bg-purple-900 text-white"
                >
                  {loc}
                </option>
              ))}
            </select>
          </div>

          <div className="mt-4 flex gap-3">
            <button
              onClick={handleSaveClick}
              className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-md"
            >
              Save
            </button>
            <button
              onClick={() => navigate(-1)}
              className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-md"
            >
              Back
            </button>
          </div>
        </div>
      </main>

      <Footer />

      {/* Confirmation Modal */}
      {showConfirm && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white text-black rounded-lg p-6 max-w-lg w-full">
            <h3 className="text-lg font-bold mb-4">Confirm Changes</h3>
            <ul className="mb-4 list-disc pl-5">
              {Object.entries(changes).map(([field, { old, new: newVal }]) => (
                <li key={field}>
                  <strong>{field}:</strong> "{old}" → "{newVal}"
                </li>
              ))}
            </ul>
            <div className="flex gap-3">
              <button
                onClick={handleConfirmSave}
                className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-md"
              >
                Confirm
              </button>
              <button
                onClick={() => setShowConfirm(false)}
                className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-md"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UpdateContact;
